// exporting a class of product which will initialize name and price

export class Product
{
    constructor(name, price)
    {
        this.name = name;
        this.price = price;
    }
}